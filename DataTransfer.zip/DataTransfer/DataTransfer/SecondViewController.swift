//
//  SecondViewController.swift
//  DataTransfer
//
//  Created by Nilesh Uttekar on 27/09/16.
//  Copyright © 2016 Nilesh Uttekar. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    var userInfo : UserData!
    override func viewDidLoad() {
        super.viewDidLoad()
        print("UserName : \(userInfo.userName) and UserID : \(userInfo.userId)")
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
