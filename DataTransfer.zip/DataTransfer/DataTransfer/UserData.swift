//
//  UserData.swift
//  DataTransfer
//
//  Created by Nilesh Uttekar on 27/09/16.
//  Copyright © 2016 Nilesh Uttekar. All rights reserved.
//

import Foundation

class UserData: NSObject {
    
    var userName : String!
    var userId : String!
}